import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialogRef } from '@angular/material';
import { AngularFirestore } from 'angularfire2/firestore';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {

  constructor(private afs: AngularFirestore, private dialogRef:MatDialogRef<DialogComponent>) { }

  category = {
    categoryItems: [],
    categoryItemsList: [],
    cateroryHRList: [],
    isHR: false,
    cateroryItem: new FormControl(),
    cateroryItemList: new FormControl(),
    cateroryHR: new FormControl(),
    isValid: false


  }
  ngOnInit() {

    this.afs.collection('category').valueChanges().subscribe(data=>{
      this.category.categoryItems = data;
    // this.category.categoryItems = JSON.parse("[{\"id\":\"3tvyjniBhor6ogd2eeyR\",\"name\":\"Celebrating festivals\"},{\"id\":\"SDt2IGi4iNx745JTwLsJ\",\"name\":\"HR Activitity\"},{\"id\":\"CDDnAoN7GniqhP8w4vcZ\",\"name\":\"Celebrating diversity\"}]")
    })

  }

  selected(item, type) {
    if (type == 'category') {
      this.category.isHR = item.value.name == 'HR Activitity'
      this.afs.collection('category').doc(item.value.id).valueChanges().subscribe((data: any) => {
        if (this.category.isHR) {
          this.category.cateroryHRList = data.list;
        }
        else {
          this.category.categoryItemsList = data.list;
        }
      })

    }
    else if (type == 'hrcategory') {

      this.afs.collection('category').doc(this.category.cateroryItem.value.id).collection(item.value).valueChanges().subscribe(data => {
        if (data) {
          this.category.categoryItemsList = data[0].list
        }
      })
    }

    this.category.isValid = this.category.cateroryItem.value &&(this.category.cateroryHR.value || this.category.cateroryItemList.value )
  }

  submit(){
    let obj = {
      Category:this.category.cateroryItem.value.name,
      Activity:this.category.cateroryHR.value,
      Type:this.category.cateroryItemList.value
    }


    this.dialogRef.close(obj);
  }

  close(){
    this.dialogRef.close();
  }
}
