import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { AngularFirestore } from 'angularfire2/firestore';
import { AlertService } from 'src/app/service/alert.service';
import { DialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  dialogRef:MatDialogRef<DialogComponent>;


  constructor(private afs:AngularFirestore, private dialog: MatDialog, private alertService:AlertService,
      private http:HttpClient
    ) { }

  ngOnInit() {
  }


  addOrder() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '600px';
    dialogConfig.direction = 'ltr';
    dialogConfig.closeOnNavigation = true;
    this.dialogRef = this.dialog.open(DialogComponent,
      dialogConfig
    );

    this.dialogRef.afterClosed().subscribe(
      (result) => {   
        if(!result) return;
        let headers = {
          headers : new HttpHeaders({
            'Content-Type' :'application/json'
          })
        }


        this.http.post("http://localhost:90/email",result,headers).subscribe(data=>{
          this.alertService.ShowSuccessToast('Event Created Succesfully.')
        },error=>{
          if(error.status == 200){
          this.alertService.ShowSuccessToast('Event Created Succesfully.')
          }
        })
      })
  }

}
